-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2017 at 04:45 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbchat`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbllogin`
--

CREATE TABLE `tbllogin` (
  `id` int(3) NOT NULL,
  `username` varchar(30) CHARACTER SET utf8 NOT NULL,
  `password` varchar(40) CHARACTER SET utf8 NOT NULL,
  `fullname` varchar(150) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ujis;

--
-- Dumping data for table `tbllogin`
--

INSERT INTO `tbllogin` (`id`, `username`, `password`, `fullname`) VALUES
(1, 'jmmaguigad', 'espionage28', 'John Manuel Macatuggal Maguigad'),
(2, 'joe', 'joe123', 'joe joe joe jr.'),
(3, 'crespy', 'crespy', 'crespy');

-- --------------------------------------------------------

--
-- Table structure for table `user_chat_messages`
--

CREATE TABLE `user_chat_messages` (
  `id` int(11) NOT NULL,
  `message_content` text NOT NULL,
  `username` varchar(20) NOT NULL,
  `message_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `recipient` varchar(50) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_chat_messages`
--

INSERT INTO `user_chat_messages` (`id`, `message_content`, `username`, `message_time`, `recipient`) VALUES
(1, ':b', ':a', '0000-00-00 00:00:00', ':d'),
(2, 'easdasdadad', 'jmmaguigad', '2014-01-05 17:00:00', 'joe'),
(3, 'dasdad', 'jmmaguigad', '2014-01-05 17:00:00', 'joe'),
(4, 'dasdasd', 'jmmaguigad', '0000-00-00 00:00:00', 'joe'),
(5, 'dasdad', 'jmmaguigad', '0000-00-00 00:00:00', 'joe'),
(6, 'asdas', 'jmmaguigad', '0000-00-00 00:00:00', 'joe'),
(7, 'hello\n', 'joe', '0000-00-00 00:00:00', 'jmmaguigad'),
(8, 'how are you', 'joe', '0000-00-00 00:00:00', 'jmmaguigad'),
(9, 'hello', 'crespy', '0000-00-00 00:00:00', 'jmmaguigad'),
(10, 'how far', 'crespy', '0000-00-00 00:00:00', 'joe'),
(11, 'am ok', 'joe', '0000-00-00 00:00:00', 'crespy'),
(12, 'hello', 'joe', '0000-00-00 00:00:00', 'crespy'),
(13, 'dfsfdsf', 'joe', '0000-00-00 00:00:00', 'jmmaguigad'),
(14, 'hmmm', 'joe', '0000-00-00 00:00:00', 'crespy'),
(15, 'dfdsfsdf', 'joe', '0000-00-00 00:00:00', 'jmmaguigad'),
(16, 'fxvdfd', 'crespy', '0000-00-00 00:00:00', 'joe'),
(17, 'hmmm', 'joe', '0000-00-00 00:00:00', 'crespy'),
(18, 'sdfsd', 'crespy', '0000-00-00 00:00:00', 'jmmaguigad'),
(19, 'yh', 'joe', '0000-00-00 00:00:00', 'jmmaguigad'),
(20, 'hello', 'crespy', '0000-00-00 00:00:00', 'jmmaguigad'),
(21, 'hjdbsjhbdksad', 'joe', '2017-08-23 04:44:22', 'crespy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbllogin`
--
ALTER TABLE `tbllogin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_chat_messages`
--
ALTER TABLE `user_chat_messages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbllogin`
--
ALTER TABLE `tbllogin`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user_chat_messages`
--
ALTER TABLE `user_chat_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
